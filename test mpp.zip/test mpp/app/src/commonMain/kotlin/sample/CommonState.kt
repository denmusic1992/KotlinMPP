package sample

data class CommonState(val text: String)