package sample

interface DateProtocol {
    fun getIosDate(): String
}