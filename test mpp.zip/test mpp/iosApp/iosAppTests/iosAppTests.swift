import XCTest
import app

class iosAppTests: XCTestCase {
    func testExample() {
        assert(Sample().checkMe() == 7)
    }
}